import java.io.IOException;

public class Main {

	
	public static void main(String[] args) throws InterruptedException, IOException {
	
		/**
		 בדיקת עומסים
		// TODO Auto-generated method stub
		//Monday x= null; 
		//x.pangoAutomatedTest();
		int n= 8;
		MondayThread[] threads = new MondayThread[n];
		for (int i = 0; i < n; i++) {
			threads[i] = new MondayThread();
		 }
		for (int i = 0; i < n; i++) {
			threads[i].start();
		 }
	**/
	
		
		
	}
	
}
